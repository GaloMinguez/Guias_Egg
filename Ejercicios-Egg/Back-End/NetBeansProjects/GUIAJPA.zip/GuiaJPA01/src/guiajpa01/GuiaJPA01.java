package guiajpa01;

import guiajpa01.entidades.Persona;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;
import javax.persistence.RollbackException;

public class GuiaJPA01 {
    public static void main(String[] args) {
        
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        
        /*Persona p1 = new Persona();
        p1.setDni("34343433");
        p1.setNombre("mauricio");
        p1.setApellido("maldonado");

        em.getTransaction().begin();
        em.persist(p1);
        em.getTransaction().commit();
        */
        
        /*Persona p2 = em.find(Persona.class, "34343431");
        System.out.println(p2);
        
        p2.setNombre("anita");
        p2.setApellido("sacco");
        
        em.getTransaction().begin();
        em.merge(p2);
        em.getTransaction().commit();
        
        
        
        Persona p3 = em.find(Persona.class, "34343432");
        em.getTransaction().begin();
        em.remove(p3);
        em.getTransaction().commit();
        */
        List<Persona> p = em.createQuery("SELECT p FROM Persona p WHERE p.nombre = :name AND p.apellido = :lastName ").setParameter("name","mauricio").setParameter("lastName"  , "maldonado").getResultList();
        
        for (Persona persona : p) {
            System.out.println(persona);
        }
        
    }
}
